<?php
namespace App\Http\Controller;

use OpenApi\Generator;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class DocsController
{
    public function swaggerJson(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        try {
            // Сканируем директорию src для поиска аннотаций OpenAPI
            $openapi = Generator::scan([__DIR__ . '/../../']);
            $json = $openapi->toJson();
            
            $response->getBody()->write($json);
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withHeader('Access-Control-Allow-Origin', '*')
                ->withHeader('Access-Control-Allow-Methods', 'GET, OPTIONS')
                ->withHeader('Access-Control-Allow-Headers', 'Content-Type');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode([
                'error' => 'Failed to generate OpenAPI documentation',
                'message' => $e->getMessage()
            ]));
            return $response
                ->withStatus(500)
                ->withHeader('Content-Type', 'application/json');
        }
    }
}
