<?php

// Локальные значения окружения. Файл игнорируется git (см. .gitignore)
return [
    'APP_NAME'    => 'Puma',
    'APP_VERSION' => '0.0.1',

    // Identity / JWT
    'HASH_KEY'    => 'testKey',
    'CLIENT_IDS'  => 'web_app',
    'JWT_SECRET'  => 'FV2s8H7uh7kb4lXBq7ju8vzHlc6YmEQesabfUj5llp',

    // Database
    'DB_HOST'     => 'localhost',
    'DB_NAME'     => 'cv82602_slimdev',
    'DB_USER'     => 'cv82602_slimdev',
    'DB_PASS'     => '4YxsN8Pp',
];


